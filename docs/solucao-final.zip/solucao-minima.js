/**
 * SOLUÇÃO MÍNIMA PARA GITHUB PAGES
 * 
 * Esta é uma versão ultra simplificada que:
 * 1. Oculta as informações de distância e tempo nas rotas alternativas
 * 2. Cria um painel simples para mostrar essas informações
 */
(function() {
  console.log("🛠️ [Solução Mínima] Iniciando...");
  
  // Executar quando a página carrega
  window.addEventListener('load', iniciar);
  
  // Também tentar imediatamente
  setTimeout(iniciar, 200);
  
  // E em intervalos
  [500, 1000, 2000, 3000, 5000].forEach(tempo => {
    setTimeout(iniciar, tempo);
  });
  
  function iniciar() {
    console.log("🛠️ [Solução Mínima] Aplicando ajustes...");
    
    // 1. Injetar CSS principal
    injetarCSS();
    
    // 2. Ocultar informações nas rotas alternativas
    ocultarInformacoesRotas();
    
    // 3. Adicionar painel
    adicionarPainelDeInformacoes();
  }
  
  function injetarCSS() {
    // Evitar duplicação
    if (document.getElementById('css-solucao-minima')) {
      return;
    }
    
    const estilo = document.createElement('style');
    estilo.id = 'css-solucao-minima';
    estilo.innerHTML = `
      /* Ocultar elementos de distância e tempo nas rotas alternativas */
      .route-alternative .route-distance,
      .route-alternative .route-time,
      .alternative .route-distance,
      .alternative .route-time,
      div.mb-2 .route-distance,
      div.mb-2 .route-time,
      .route-info .route-distance,
      .route-info .route-time {
        display: none !important;
        visibility: hidden !important;
      }
      
      /* Estilo para o novo painel */
      .info-painel {
        display: inline-flex;
        margin-left: 15px;
        padding: 6px 10px;
        background-color: #fff9e6;
        border: 1px solid #ffd966;
        border-radius: 4px;
        font-size: 14px;
        align-items: center;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
      }
      
      .info-painel-item {
        margin-right: 15px;
      }
      
      .info-painel-item:last-child {
        margin-right: 0;
      }
      
      /* Amarelo Móveis Bonafé */
      #visualize-button, 
      button.btn-primary,
      button.btn-secondary {
        background-color: #ffd966 !important;
        border-color: #e6c259 !important;
        color: #212529 !important;
      }
    `;
    
    document.head.appendChild(estilo);
    console.log("🛠️ [Solução Mínima] CSS adicionado");
  }
  
  function ocultarInformacoesRotas() {
    // Encontrar todas as rotas alternativas
    const seletores = [
      '.route-alternative',
      '.alternative',
      '.routes-container div.card',
      '.routes-container div.mb-2',
      '.route-alternative-box div'
    ];
    
    let rotasEncontradas = 0;
    
    for (const seletor of seletores) {
      const elementos = document.querySelectorAll(seletor);
      if (elementos.length > 0) {
        rotasEncontradas += elementos.length;
        elementos.forEach(el => {
          // Ocultar elementos de tempo e distância
          const distancia = el.querySelector('.route-distance, .distance, [class*="distance"]');
          const tempo = el.querySelector('.route-time, .time, [class*="time"]');
          
          if (distancia) distancia.style.display = 'none';
          if (tempo) tempo.style.display = 'none';
          
          // Ou ocultar via propriedade de visibilidade direta
          el.querySelectorAll('*').forEach(child => {
            const texto = child.textContent || '';
            if ((texto.includes('km') || texto.includes('min')) && child.children.length === 0) {
              child.style.display = 'none';
            }
          });
        });
      }
    }
    
    if (rotasEncontradas > 0) {
      console.log(`🛠️ [Solução Mínima] ${rotasEncontradas} rotas alternativas encontradas e processadas`);
    } else {
      console.log("🛠️ [Solução Mínima] Nenhuma rota alternativa encontrada");
    }
  }
  
  function adicionarPainelDeInformacoes() {
    // Evitar duplicação
    if (document.querySelector('.info-painel')) {
      return;
    }
    
    // Encontrar o botão Visualizar
    const botaoVisualizar = encontrarBotaoVisualizar();
    
    if (!botaoVisualizar) {
      console.log("🛠️ [Solução Mínima] Botão Visualizar não encontrado");
      return;
    }
    
    // Criar o painel
    const painel = document.createElement('div');
    painel.className = 'info-painel';
    painel.innerHTML = `
      <div class="info-painel-item">
        <i class="fa fa-road" style="margin-right: 5px;"></i>
        <span class="info-distancia">- km</span>
      </div>
      <div class="info-painel-item">
        <i class="fa fa-clock" style="margin-right: 5px;"></i>
        <span class="info-tempo">- min</span>
      </div>
    `;
    
    // Adicionar o painel após o botão
    try {
      const parent = botaoVisualizar.parentNode;
      if (botaoVisualizar.nextSibling) {
        parent.insertBefore(painel, botaoVisualizar.nextSibling);
      } else {
        parent.appendChild(painel);
      }
      console.log("🛠️ [Solução Mínima] Painel de informações adicionado");
      
      // Adicionar Font Awesome
      if (!document.querySelector('link[href*="font-awesome"]')) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css';
        document.head.appendChild(link);
      }
      
      // Interceptar clique no botão para pegar informações
      adicionarInterceptadorDeClique(botaoVisualizar);
    } catch (e) {
      console.log("🛠️ [Solução Mínima] Erro ao adicionar painel:", e);
    }
  }
  
  function encontrarBotaoVisualizar() {
    // Estratégia 1: Por ID
    let botao = document.getElementById('visualize-button');
    if (botao) return botao;
    
    // Estratégia 2: Por classe e texto
    const botoesClasse = document.querySelectorAll('.btn, .btn-primary, .button');
    for (let i = 0; i < botoesClasse.length; i++) {
      if (botoesClasse[i].textContent.includes('Visualizar')) {
        return botoesClasse[i];
      }
    }
    
    // Estratégia 3: Qualquer botão com o texto
    const botoes = document.querySelectorAll('button');
    for (let i = 0; i < botoes.length; i++) {
      if (botoes[i].textContent.includes('Visualizar')) {
        return botoes[i];
      }
    }
    
    // Estratégia 4: Qualquer elemento clicável com o texto
    const elementos = document.querySelectorAll('a, div[onclick], span[onclick]');
    for (let i = 0; i < elementos.length; i++) {
      if (elementos[i].textContent.trim() === 'Visualizar') {
        return elementos[i];
      }
    }
    
    return null;
  }
  
  function adicionarInterceptadorDeClique(botao) {
    // Guardar o manipulador original
    const clickOriginal = botao.onclick;
    
    // Adicionar novo manipulador
    botao.addEventListener('click', function(e) {
      // Chamar o original se existir
      if (typeof clickOriginal === 'function') {
        try {
          clickOriginal.call(this, e);
        } catch (err) {
          console.log("🛠️ [Solução Mínima] Erro ao chamar handler original:", err);
        }
      }
      
      // Aguardar um pouco para pegar as informações
      setTimeout(function() {
        atualizarInformacoesNoPainel();
      }, 500);
    });
  }
  
  function atualizarInformacoesNoPainel() {
    // Tentar encontrar informações de rota
    let distanciaTexto = '- km';
    let tempoTexto = '- min';
    
    // Estratégia 1: Buscar em divs de rota selecionadas
    const rotaSelecionada = document.querySelector('.route-alternative.selected, .alternative.selected, .rota-selecionada');
    if (rotaSelecionada) {
      // Extrair texto
      const texto = rotaSelecionada.textContent || '';
      const matchDistancia = texto.match(/(\d+[.,]?\d*\s*km)/i);
      const matchTempo = texto.match(/(\d+\s*min|\d+\s*hora[s]?)/i);
      
      if (matchDistancia) distanciaTexto = matchDistancia[0];
      if (matchTempo) tempoTexto = matchTempo[0];
    }
    // Estratégia 2: Buscar em elementos que têm estas informações
    else {
      // Distância
      const elementosDistancia = document.querySelectorAll('.route-distance, .distance');
      for (let i = 0; i < elementosDistancia.length; i++) {
        if (elementosDistancia[i].offsetParent !== null) { // Elemento visível
          distanciaTexto = elementosDistancia[i].textContent.trim();
          break;
        }
      }
      
      // Tempo
      const elementosTempo = document.querySelectorAll('.route-time, .time');
      for (let i = 0; i < elementosTempo.length; i++) {
        if (elementosTempo[i].offsetParent !== null) { // Elemento visível
          tempoTexto = elementosTempo[i].textContent.trim();
          break;
        }
      }
    }
    
    // Atualizar elementos
    const elDistancia = document.querySelector('.info-distancia');
    const elTempo = document.querySelector('.info-tempo');
    
    if (elDistancia) elDistancia.textContent = distanciaTexto;
    if (elTempo) elTempo.textContent = tempoTexto;
    
    console.log(`🛠️ [Solução Mínima] Informações atualizadas: ${distanciaTexto}, ${tempoTexto}`);
  }
})();