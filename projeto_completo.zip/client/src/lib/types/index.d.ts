interface Window {
  initMap: () => void;
  google: typeof google;
}

declare var google: any;